import Controller.BohnanzaController;
import View.ModeSelectFrame;

public class BohnanzaApplication {
	
	public static void main(String[] args) {
		
		ModeSelectFrame game = new ModeSelectFrame();
	
	}
}
